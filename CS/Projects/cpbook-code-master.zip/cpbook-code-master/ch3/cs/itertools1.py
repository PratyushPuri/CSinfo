import itertools
p = list(itertools.permutations(range(7)))        # iterate through p
print(len(p))                                     # should be 7! = 5040
