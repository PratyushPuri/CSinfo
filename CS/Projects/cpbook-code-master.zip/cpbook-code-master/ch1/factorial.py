import math
print(math.factorial(25))
