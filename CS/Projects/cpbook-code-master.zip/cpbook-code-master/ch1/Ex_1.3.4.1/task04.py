print(*sorted(set(input().split()), key=int), sep='\n')
