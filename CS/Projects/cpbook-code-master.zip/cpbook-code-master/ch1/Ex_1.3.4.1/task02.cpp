#include <bits/stdc++.h>                         // C++ code for task 2
int main() {
  int n; scanf("%d", &n);
  printf("%.*lf\n", n, M_PI);                    // adjust field width
}
