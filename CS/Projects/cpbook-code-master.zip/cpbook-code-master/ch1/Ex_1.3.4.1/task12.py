print(eval(input()))
