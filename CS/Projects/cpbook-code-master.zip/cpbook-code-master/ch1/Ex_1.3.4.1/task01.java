import java.util.*;                              // Java code for task 1
class Main {
  public static void main(String[] args) {       // Java has printf too!
    System.out.printf("%7.3f\n", new Scanner(System.in).nextDouble());
  }
}
